package com.edz.edz_esapi.utils;

public class ESconst {
    public static final String ES_INDEX = "test";

}
