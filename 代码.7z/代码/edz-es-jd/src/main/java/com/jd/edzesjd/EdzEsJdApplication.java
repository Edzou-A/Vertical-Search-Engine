package com.jd.edzesjd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EdzEsJdApplication {

    public static void main(String[] args) {
        SpringApplication.run(EdzEsJdApplication.class, args);
    }

}
